import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from attention import ClassificationNetwork

data = pd.read_excel('./data/2024.02.18赋值.xlsx')
# 分离特征和标签
# X = data.drop(['diagnosis', 'ID'], axis=1).values
X = data.drop(['diagnosis'], axis=1).values
y = data['diagnosis'].values

# 训练模型
accuracies = []
for i in range(50):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=47)

    # 数据标准化
    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    # 转换为张量
    X_train = torch.FloatTensor(X_train)
    y_train = torch.LongTensor(y_train)
    X_test = torch.FloatTensor(X_test)
    y_test = torch.LongTensor(y_test)

    # 创建数据加载器
    train_data = TensorDataset(X_train, y_train)
    train_loader = DataLoader(train_data, batch_size=32)
    model = ClassificationNetwork(X_train.shape[1], 25)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.0049, weight_decay=0.003)
    for epoch in range(18):
        for inputs, labels in train_loader:
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

    torch.save(model.state_dict(), f'weights/model_weights_{i}.pth')

    # 评估模型
    with torch.no_grad():
        model.eval()
        outputs = model(X_test)
        _, predicted = torch.max(outputs, 1)
        accuracy = (predicted == y_test).sum().item() / len(y_test)
        accuracies.append(accuracy)
    print(f'i: {i}', f'Accuracy: {accuracy * 100}%')

# 计算平均精度
mean_accuracy = sum(accuracies) / len(accuracies)
print('Mean accuracy: {:.2f}%'.format(mean_accuracy * 100))