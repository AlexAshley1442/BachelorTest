import torch
import torch.nn as nn
import torch.nn.functional as F

class Attention(nn.Module):
    def __init__(self, feature_dim, hidden_dim):
        super(Attention, self).__init__()
        self.feature_dim = feature_dim # 注意力头数
        self.hidden_dim = hidden_dim # 数据维度
        self.W = nn.Linear(feature_dim, hidden_dim)
        self.V = nn.Linear(hidden_dim, 1)

    def forward(self, features):
        # 将特征量转换为嵌入向量
        embedded_features = self.W(features)
        # 计算特征量之间的兴趣权重
        attention_weights = F.softmax(self.V(torch.tanh(embedded_features)), dim=1)
        # 将兴趣权重与嵌入向量相乘，得到加权的嵌入向量
        weighted_features = attention_weights * embedded_features
        # 返回加权的嵌入向量
        return weighted_features

class ClassificationNetwork(nn.Module):
    def __init__(self, feature_dim, hidden_dim):
        super(ClassificationNetwork, self).__init__()
        self.attention = Attention(feature_dim, hidden_dim)
        self.classifier = nn.Sequential(
            nn.Linear(feature_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.15),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(0.15),
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Dropout(0.15),
            nn.Linear(16, 2),
            nn.Softmax(dim=1)
        )

    def forward(self, features):
        # 使用注意力模块计算加权的嵌入向量
        weighted_features = self.attention(features)
        # print(weighted_features.shape)

        # 将加权的嵌入向量输入到分类网络中
        logits = self.classifier(weighted_features)
        # 返回分类结果
        return logits