import pandas as pd

# 创建示例数据
data = pd.read_excel('..\data/add_data.xlsx')
# 计算皮尔逊相关系数
num_cols = data.shape[1]
result_df = pd.DataFrame(columns=['Feature', '协方差'])
for i in range(num_cols-2):
    column_B = data.columns[i+2]  # 其他列的列名

    data_A = data.iloc[:, 1]
    data_B = data.iloc[:, i+2]
    data_B = data_B.dropna()  # 删除含有NaN的行
    correlation = data_A.cov(data_B)
    result_df = pd.concat([result_df, pd.DataFrame([[column_B, correlation]], columns=result_df.columns)], ignore_index=True)
    # print("{}: {:.4f}".format(column_B, correlation))
result_df.to_excel('协方差_results.xlsx', index=False)