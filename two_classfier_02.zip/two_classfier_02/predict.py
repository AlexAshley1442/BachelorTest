import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from attention import ClassificationNetwork


data = pd.read_excel('./data/2024.02.18赋值.xlsx')
# 分离特征和标签
X = data.drop(['diagnosis'], axis=1).values
# print(X)
y = data['diagnosis'].values
# 训练模型
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=32)

    # 数据标准化
sc = StandardScaler()
X_test = sc.fit_transform(X_test)

    # 转换为张量
X_test = torch.FloatTensor(X_test)
y_test = torch.LongTensor(y_test)

    # 创建模型和载入最优权重
    # model = nn.Sequential(
    #         nn.Linear(X_train.shape[1], 64),
    #         nn.ReLU(),
    #         nn.Dropout(0.1),
    #         nn.Linear(64, 32),
    #         nn.ReLU(),
    #         nn.Dropout(0.1),
    #         nn.Linear(32, 16),
    #         nn.ReLU(),
    #         nn.Dropout(0.1),
    #         nn.Linear(16, 2),
    #         nn.Softmax(dim=1)
    #     )

model = ClassificationNetwork(X_train.shape[1], 25)

    # 选择最佳权重文件并加载
best_model_weights_path = 'weight_best/218model_weights_0.pth'
model.load_state_dict(torch.load(best_model_weights_path))

    # 评估模型
with torch.no_grad():
    model.eval()
    outputs = model(X_test)
    _, predicted = torch.max(outputs, 1)
    accuracy = (predicted == y_test).sum().item() / len(y_test)
print(f'Accuracy: {accuracy * 100}%')

