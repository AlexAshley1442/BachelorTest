import pandas as pd
import torch
from torch.utils import data
from data_loader import dataloader
from model import Net
import torch.nn as nn
from log_rmse import log_rmse
# 超参数


def train(train_feature, train_label, test_feature, test_label, epochs, weight_decay, lr, batch_size):
    # 创建数据集
    dataset_train = data.TensorDataset(train_feature, train_label)
    dataset_test = data.TensorDataset(test_feature, test_label)
    train_iter = data.DataLoader(dataset_train, batch_size, shuffle=True)
    test_iter = data.DataLoader(dataset_test, batch_size, shuffle=True)
    # 网络模型
    mynet = Net()

    # 损失函数
    Loss_fn = nn.CrossEntropyLoss()

    # 训练器选择AdamW,用于限制模型参数的大小，减小过拟合的风险。这样可以有效地控制模型复杂度，防止在特征较多的情况下出现过度拟合。
    optimizer = torch.optim.AdamW(params=mynet.parameters(), lr=lr, weight_decay=weight_decay)
    train_ls, test_ls = [], []

    # 训练模块
    for i in range(epochs):
        for feature, label in train_iter:
            output = mynet(feature)
            Loss = Loss_fn(output, label.long())

            optimizer.zero_grad()
            Loss.backward()
            optimizer.step()
        train_ls.append(Loss)
        if test_label is not None:
            for feature, label in test_iter:
                test_ls.append(Loss_fn(feature, label.long()))
        return train_ls, test_ls




