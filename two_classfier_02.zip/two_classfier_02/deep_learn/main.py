import pandas as pd
import torch
from torch.utils import data
from data_loader import dataloader
from model import Net
import torch.nn as nn
from trainer import train
from K_fold_data import get_k_fold_data
from d2l import torch as d2l

def k_fold(k, all_feature, all_label, epochs,
           lr, weight_decay, batch_size):
    train_l_sum, valid_l_sum = 0, 0
    for i in range(k):
        data = get_k_fold_data(k, i, all_feature, all_label)
        train_ls, valid_ls = train(*data, epochs=epochs, weight_decay=weight_decay, lr=lr, batch_size=batch_size)
        train_l_sum += train_ls[-1]
        valid_l_sum += valid_ls[-1]

        print('fold %d, train rmse %f, valid rmse %f' % (i, train_ls[-1], valid_ls[-1]))
    return train_l_sum / k, valid_l_sum / k

# 设置超参数
lr = 0.001
epoch = 50
weight_decay = 0.01
data_path = '../data/add_data.xlsx'
k=5
batch_size=8

train_feature, train_label = dataloader(data_path)
train_l, valid_l = k_fold(k, train_feature, train_label, epoch, lr, weight_decay, batch_size)

print('%d-fold validation: avg train rmse %f, avg valid rmse %f' % (k, train_l, valid_l))

