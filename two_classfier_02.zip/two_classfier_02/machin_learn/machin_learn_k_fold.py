import pandas as pd
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

# 读入你给我1b表
data = pd.read_excel('..\data/add_data.xlsx')

scaler = StandardScaler()

x = pd.concat([data.iloc[:, 2:]])
x = scaler.fit_transform(x)
x = pd.DataFrame(x)
y = pd.concat([data.iloc[:, 1]])
# 定义交叉验证折数
k = 6

# 创建随机森林分类器
num = 20
for i in range(num):
    for j in range(num):
        rf = RandomForestClassifier(n_estimators=100, random_state=i)

        # 创建K折交叉验证对象
        kf = KFold(n_splits=k, shuffle=True, random_state=j)

        # 定义评估指标列表
        accuracy_list = []

        # 循环进行交叉验证
        for train_index, val_index in kf.split(x):
            x_train, x_val = x.iloc[train_index], x.iloc[val_index]
            y_train, y_val = y.iloc[train_index], y.iloc[val_index]
            # 使用训练集拟合模型
            rf.fit(x_train, y_train)
            # 在验证集上进行预测
            y_pred = rf.predict(x_val)
            # 计算准确率
            accuracy = accuracy_score(y_val, y_pred)
            # print(accuracy)
            accuracy_list.append(accuracy)
        # 计算平均准确率
        average_accuracy = sum(accuracy_list) / k
        # 输出最终评估结果
        print("i:{}, j:{},平均准确率:", i,j,average_accuracy)
