import pandas as pd
from sklearn.ensemble import RandomForestClassifier
# from sklearn.ensemble import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

data = pd.read_excel('..\data\ID.xlsx')
all_feather = pd.concat([data.iloc[:, 2:]])
all_label = pd.concat([data.iloc[:, 1]])

x_train, x_test, y_train, y_test = train_test_split(all_feather, all_label, train_size=0.8, random_state=10, shuffle=True)
# 创建逻辑回归分类器
rf = RandomForestClassifier(n_estimators=100, random_state=50)
# 使用训练数据拟合分类器
rf.fit(x_train, y_train)

# 使用测试数据预测标签
y_pred = rf.predict(x_test)
print(y_pred.reshape(-1))
print(y_test.to_numpy().reshape(-1))
# 计算预测准确率
accuracy = accuracy_score(y_test, y_pred)

print('预测准确率:', accuracy)


# 预测概率
# y_pred_pro = rf.predict_proba(x_test)
# print(y_pred_pro)

