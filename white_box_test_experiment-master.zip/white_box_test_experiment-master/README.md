# 测试用例，需要maven构建 需要将测试用例的类，改为public

# checkstyle Maven 命令
mvn checkstyle:checkstyle
# site Maven 命令
mvn site
# test report Maven 命令
mvn test surefire-report:report

# maven 构建完整命令
clean install checkstyle:checkstyle surefire-report:report site 
