package cn.swust.software.unittest.demo;

public class AddTwoFun {
	public int add(int a, int b)
	{
		return a - b;
	} 
}
