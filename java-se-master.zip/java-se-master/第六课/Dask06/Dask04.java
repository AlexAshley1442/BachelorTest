package Dask06;

import java.util.Arrays;

public class Dask04 {
    public static int[] copyOf(int[] arrays1){
        int[] arr=new int[arrays1.length];
        for(int i=0;i< arrays1.length;i++){
            arr[i]=arrays1[i];
        }
        return arr;
    }
    public static void main(String[] args) {
        int[] arrays={1,2,3,4,5,6,7};
        int[] arrays1=copyOf(arrays);
        System.out.println(Arrays.toString(arrays1));
    }
}
