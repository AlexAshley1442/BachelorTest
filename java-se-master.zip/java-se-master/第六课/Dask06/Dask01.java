package Dask06;

import java.util.Arrays;

public class Dask01 {
    public static void bubbleSort(int[] arrays){
        boolean a=false;
        for(int i=0;i<arrays.length-1;i++){
            for(int j=0;j<arrays.length-1-i;j++){
                if(arrays[j]>arrays[j+1]){
                    int temp=arrays[j];
                    arrays[j]=arrays[j+1];
                    arrays[j+1]=temp;
                    a=true;
                }
            }
            if(a==false){
                break;
            }
        }
    }
    public static void main(String[] args) {
        int[] arrays={12,34,13,45,23};
        bubbleSort(arrays);
        System.out.println(Arrays.toString(arrays));
    }
}
