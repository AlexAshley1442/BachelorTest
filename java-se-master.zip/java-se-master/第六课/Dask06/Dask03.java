package Dask06;

public class Dask03 {
    public static int mybinarySearch(int[] arr,int a){
        int left=0;
        int right= arr.length-1;
        while (left<=right) {
            int mid=(left+right)/2;
            if (arr[mid] < a) {
                left = mid + 1;
            } else if (arr[mid] > a) {
                right = mid - 1;
            } else {
                return mid;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int[] arryas={1,2,3,4,5,6,7,8,9,10};
        int a=2;
        System.out.println(mybinarySearch(arryas,a));
    }
}
