package Dask06;

public class Dask05 {
    public static String mytoString(int[] arrays){
        String num="[";
        for(int i=0;i< arrays.length;i++){
            num=num+arrays[i];
            if(i!= arrays.length-1) {
                num = num + ",";
            }
        }
        return num+"]";
    }
    public static void main(String[] args) {
        int[] arrays={1,2,3,4,5,6,7};
        System.out.println(mytoString(arrays));
    }
}
