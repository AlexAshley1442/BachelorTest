package Test12;

public class Prac01 {
    public Node getIntersectionNode(Node headA, Node headB) {
        if(headA==null||headB==null){
            return null;
        }
        Node last=headB;
        while (last.next!=null){
            last=last.next;
        }
        last.next=headB;

        Node fast=headA;
        Node slow=headA;
        while (fast!=null&&fast.next!=null){
            fast=fast.next.next;
            slow=slow.next;
            if(fast==slow){
                break;
            }
        }
        if(fast==null||fast.next==null){
            last.next=null;
            return null;
        }

        fast=headA;
        while (fast!=slow){
            fast=fast.next;
            slow=slow.next;
        }
        last.next=null;
        return fast;
    }
}
