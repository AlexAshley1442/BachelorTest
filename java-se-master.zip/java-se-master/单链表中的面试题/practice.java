package Test12;

public class practice {
    public Node deleteDuplication(Node pHead) {
        Node newNode=new Node(-1);
        Node temp=newNode;
        Node cur=pHead;
        while (cur!=null){
            if(cur.next!=null&&cur.val==cur.next.val){
                while (cur.next!=null&&cur.val==cur.next.val){
                    cur=cur.next;
                }
                cur=cur.next;
            }else {
                temp.next=cur;
                temp=temp.next;
                cur=cur.next;
            }
        }
        temp.next=null;
        return newNode.next;
    }
}
