package Test12;

public class practice02 {
    public Node deleteDuplication(Node pHead) {
        if(pHead==null||pHead.next==null)return pHead;
        Node node=new Node(-1);
        node.next=pHead;
        Node pev=node;
        Node cur=node.next;
        while (cur!=null){
            if(cur.val==cur.next.val){
                cur=cur.next;
                if(cur.val!=cur.next.val){
                    pev.next=cur.next;
                    cur=cur.next;
                }
            }else{
                pev=cur;
                cur=cur.next;
            }
        }

        return node.next;
    }
}
