package Test12;
class Node{
    public int val;
    public Node next;

    public Node(int val) {
        this.val = val;
    }
}
public class practice01 {
    public Node partition(Node pHead, int x) {
        Node bs=null;
        Node be=null;
        Node as=null;
        Node ae=null;
        Node cur=pHead;
        while (cur!=null){
            if(cur.val<x){
                //第一次
                if(bs==null){
                    bs=cur;
                    be=cur;
                }else {
                    //不是第一次
                    be.next=cur;
                    be=be.next;
                }
            }else{
                if(as==null){
                    as=cur;
                    ae=cur;
                }else {
                    //不是第一次
                    ae.next=cur;
                    ae=ae.next;
                }
            }
            cur=cur.next;
        }
        if(bs==null)return as;
        be.next=as;
        if(ae!=null) {
            ae.next = null;
        }
        return bs;
    }
}
