package Dask;

public class Dest07 {
    public static void main(String[] args) {
        double add1=0,add2=0;
        for(double i=1;i<=100;i+=2){
            add1=add1+1/i;
        }

        for(double j=2;j<=100;j+=2){
            add2=add2+1/j;
        }

        double add=add1-add2;
        System.out.println(add);
    }
}
