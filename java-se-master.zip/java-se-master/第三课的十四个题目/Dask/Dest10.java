package Dask;

import java.util.Scanner;

public class Dest10 {
    public static void main(String[] args) {
        int i=0;
        Scanner sca=new Scanner(System.in);
        while (sca.hasNext()){
            int cipher=sca.nextInt();
            if(cipher==123456){
                System.out.println("密码正确，输入成功");
                break;
            }else{
                System.out.println("密码错误，请重新输入");
            }
            i++;
            if(i==3){
                break;
            }
        }
    }
}
