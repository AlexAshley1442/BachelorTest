package Dask;

import java.util.Scanner;

public class Dest15 {
    public static void main(String[] args) {
        Scanner sca = new Scanner(System.in);
        while (sca.hasNext()) {
            int a = sca.nextInt();
            String[][] str = new String[a][a];

            for (int i = 0; i < a; i++) {
                for (int j = 0; j < a; j++) {
                    str[i][j] = " ";
                }
            }

            for (int i = 0; i < a; i++) {
                str[i][i] = "*";
                str[i][a - 1 - i] = "*";
            }

            for (int i = 0; i < a; i++) {
                for (int j = 0; j < a; j++) {
                    System.out.print(str[i][j]);
                }
                System.out.println();
            }
        }
    }
}
