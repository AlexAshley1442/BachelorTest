package Dask;

import java.util.Scanner;

public class Dest13 {
    public static void main(String[] args) {
        Scanner sca=new Scanner(System.in);
        int a=sca.nextInt();
        int i=a;
        int j=0;
        while(i!=0){
            i=i/10;
            j++;
        }
        while(j!=0){
            System.out.print((int)(a/Math.pow(10,j-1))+" ");
            a=(int)(a%Math.pow(10,j-1));
            j--;
        }
    }
}
