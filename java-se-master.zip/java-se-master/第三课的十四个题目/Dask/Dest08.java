package Dask;

public class Dest08 {
    public static void main(String[] args) {
        for(int i=1;i<=100;i++){
            if(i/10==9||i%10==9){
                System.out.print(i+" ");
            }
        }
    }
}
