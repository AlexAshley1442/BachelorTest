package Dask;

public class Dest04 {
    public static void main(String[] args) {
        for(int i=1000;i<=2000;i++){
            if(i%400==0&&i%100!=0||i%4==0){
                System.out.print(i+" ");
            }
        }
    }
}
