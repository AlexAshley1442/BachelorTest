package Dask;

import java.util.Scanner;

public class Dask02 {
    public static void main(String[] args) {
        Scanner sca=new Scanner(System.in);
        int math=sca.nextInt();
        if(math==1&&math==2){
            System.out.println("是素数");
        }
        for(int i=2;i<math;i++){
            if(math%i==0){
                System.out.println("不是素数");
            }else{
                System.out.println("是素数");
            }
        }
    }
}
