package Dask;

import java.util.Scanner;

public class Dest12 {
    public static void main(String[] args) {
        Scanner sca=new Scanner(System.in);
        int n=sca.nextInt();
        //奇数
        for(int i=31;i>=1;i-=2){
            System.out.print(((n>>i)&1)+" ");
        }
        System.out.println();
        //偶数
        for(int i=30;i>=0;i-=2){
            System.out.print(((n>>i)&1)+" ");
        }
    }
}
