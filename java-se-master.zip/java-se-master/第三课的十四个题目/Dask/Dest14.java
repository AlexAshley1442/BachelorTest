package Dask;

import java.util.Scanner;

public class Dest14 {
    public static void main(String[] args) {
        int a=(int)(10*Math.random())+1;//生成一个1-10的数字
        Scanner sca=new Scanner(System.in);
        while (sca.hasNext()) {
            int b = sca.nextInt();
            if(b==a){
                System.out.println("恭喜你，猜对了");
                break;
            }else if(b<a){
                System.out.println("比你猜的数字大");
            }else if(a<b){
                System.out.println("比你猜的数字小");
            }
        }
    }
}
