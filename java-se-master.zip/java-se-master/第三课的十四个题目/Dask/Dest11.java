package Dask;

import java.util.Scanner;

public class Dest11 {
    public static int display(int i){
        int add=0;
        while(i!=0) {
            if (i % 2 != 0) {
                add = add + 1;
            }
            i=i/2;
        }
        return add;
    }
    public static void main(String[] args) {
        Scanner sca=new Scanner(System.in);
        int a=sca.nextInt();
        System.out.println(display(a));
    }
}
