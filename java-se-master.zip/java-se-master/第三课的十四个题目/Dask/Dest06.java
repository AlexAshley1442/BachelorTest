package Dask;

public class Dest06 {
    public static void main(String[] args) {
        int a=10;
        int b=20;
        if(a<b){
            int temp;
            temp=a;
            a=b;
            b=temp;
        }
        for(int i=b;i>0;i--){
            if(a%i==0&b%i==0){
                System.out.println(i);
                break;
            }
        }
    }
}
