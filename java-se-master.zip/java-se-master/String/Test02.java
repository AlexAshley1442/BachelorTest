package Test18;

public class Test02 {
    public static void main(String[] args) {
        StringBuffer sb=new StringBuffer("Hellow");
        sb.append("sads").append("aedad");
        System.out.println(sb);
        System.out.println(sb.reverse());
    }
}
