package Test18;

import java.util.Locale;

public class Test01 {
    public static void main(String[] args) {
        String str=" Qwer qwer ";

        String str02=str.trim();
        System.out.println(str02);

        String str03=str.toUpperCase();
        System.out.println(str03);

        String str04=str.toLowerCase();
        System.out.println(str04);

        String str05=str.intern();
        System.out.println(str05);

        String str06=str.concat("qwer");
        System.out.println(str06);

        int str07=str.length();
        System.out.println(str07);

        String m=" ";
        System.out.println(m.isEmpty());
    }

    public static void main12(String[] args) {
        String str="qwertyuio";
        String str2=str.substring(1);
        System.out.println(str2);

        String str3=str.substring(1,3);//左开右闭
        System.out.println(str3);
    }

    public static void main11(String[] args) {
        String str="name=zhangsan&age=18";
        String[] strings=str.split("&|=");
        for (String s:strings) {
            System.out.println(s);
        }
    }

    public static void main10(String[] args) {
        String str="name=zhangsan&age=18";
        String[] strings=str.split("&");
        for (String s:strings) {
            //System.out.println(s);
            String[] s1=s.split("=");
            for (String s2:s1) {
                System.out.println(s2);
            }
        }
    }

    public static void main09(String[] args) {
        String str="192.168.1.1";
        String[] strings=str.split("\\.");
        for (String s:strings) {
            System.out.println("");
        }
    }

    public static void main08(String[] args) {
        String str="hello world hellow bit";
        String[] strings=str.split(" ",2);//分成两个长度
        for (String s:strings) {
            System.out.println(s);
        }
    }

    public static void main07(String[] args) {
        String str="qwqrtqrqo";
        String str02=str.replace('q','i');
        System.out.println(str02);

        String str03=str.replaceAll("r","0");
        System.out.println(str03);

        String str04=str.replaceFirst("q","w");
        System.out.println(str04);
    }

    public static void main06(String[] args) {
        String str="abdewfsdffs";
        System.out.println(str.startsWith("d", 2));

        System.out.println(str.endsWith("fs"));
        System.out.println(str.contains("c"));
    }

    public static void main05(String[] args) {
        String str="abdewfsdffs";
        System.out.println(str.startsWith("ab"));
        System.out.println(str.startsWith("as"));
    }

    public static void main04(String[] args) {
        String str="abcqwertabcasd";
        System.out.println(str.contains("abc"));

        System.out.println(str.indexOf("bc"));

        System.out.println(str.indexOf("bc",2));

        System.out.println(str.lastIndexOf("bc"));

        System.out.println(str.lastIndexOf("bc",3));
    }

    public static void main03(String[] args) {
        String str01="string";
        String str02="String";
        System.out.println(str01.compareTo(str02));
    }
    public static void main02(String[] args) {
        String str01="String";
        String str02="string";
        System.out.println(str01.equalsIgnoreCase(str02));
    }
    public static void main01(String[] args) {
        String str01="String";
        String str02="string";
        System.out.println(str01.equals(str02));
    }
}
