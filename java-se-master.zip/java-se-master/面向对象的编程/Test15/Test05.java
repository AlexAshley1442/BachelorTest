package Test15;
class Animal{
    public String name;
    public Animal(String name){
        this.name=name;
    }
}
interface IFlying{
    void Fly();
}
interface IRunning{
    void Running();
}
interface ISwimming{
    void Swimming();
}

class Cat extends Animal implements IRunning{

    public Cat(String name) {
        super(name);
    }

    @Override
    public void Running() {
        System.out.println(this.name+"正在快乐的奔跑");
    }
}
public class Test05 {
    public static void main(String[] args) {
        Cat cat = new Cat("咪咪");
        cat.Running();
    }

}
