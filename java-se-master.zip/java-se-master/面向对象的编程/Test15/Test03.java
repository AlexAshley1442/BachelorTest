package Test15;
interface Shape01{
    abstract public void draw();
}
interface Shape02{
    abstract public void draw02();
}
class S1 implements Shape02,Shape01{

    @Override
    public void draw() {
        System.out.println(",asdasdasd");
    }

    @Override
    public void draw02() {

    }
}
public class Test03 {
    public static void main(String[] args) {
        Shape02 shape01=new S1();
    }
}
