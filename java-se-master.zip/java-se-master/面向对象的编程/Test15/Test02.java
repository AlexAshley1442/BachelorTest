package Test15;
class Shape{
    public void draw(){
        System.out.println("m");
    }
}
class Cycle extends Shape{
    @Override
    public void draw(){
        System.out.println("Q");
    }
}
class Rect extends Shape{
    @Override
    public void draw(){
        System.out.println("W");
    }
}
public class Test02 {
    public static void main(String[] args) {
        Shape shape1=new Cycle();
        Shape shape2=new Rect();
        drawShape(shape1);
        drawShape(shape2);
    }
    public static void drawShape(Shape shape){
        shape.draw();
    }
}
