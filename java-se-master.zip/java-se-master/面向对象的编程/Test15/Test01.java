package Test15;
class A{
    void fly(){
        System.out.println("wwwwwwwww");
    }
}
class B extends A{

    @Override
    void fly(){
        System.out.println("eeeeeeeee");
    }

    void size(){
        System.out.println("发生了向下转型");
    }
}
public class Test01 {
    public static void main(String[] args) {
        //向下转型
        A a=new B();
        B b=(B)a;
        b.size();
        //向下转型一定是发生了向上转型之后才能发生的

    }
    public static A find(){
        B b=new B();
        return b;
    }

    public static void feed(A a){
        a.fly();
    }
}
