package Test15;
interface IShape{
    abstract void draw();
}
class Rect01 implements IShape{

    @Override
    public void draw() {
        System.out.println("asdasdaasd");
    }
}
public class Test04 {

}
