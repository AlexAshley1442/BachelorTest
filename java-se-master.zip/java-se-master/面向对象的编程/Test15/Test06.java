package Test15;

import java.util.Arrays;
class Student{
    private String name;
    private int score;

    public Student(String name,int score){
        this.name=name;
        this.score=score;
    }

    @Override
    public String toString() {
        return "["+this.name+":"+this.score+"]";
    }
}
public class Test06 {
    public static void main(String[] args) {
        Student[] students=new Student[]{new Student("张三",12),
        new Student("李四",16)};
        System.out.println(Arrays.toString(students));
    }

}
