package practice;

public class Test01 {
    public static void main(String[] args) {
        MyLinkedList myLinkedList01=new MyLinkedList();
        myLinkedList01.addLast(1);
        myLinkedList01.addLast(8);
        myLinkedList01.addLast(14);
        myLinkedList01.addLast(21);
        myLinkedList01.addLast(8);

        myLinkedList01.dispaly();
        myLinkedList01.removeAllvel(8);
        myLinkedList01.dispaly();
    }
}
