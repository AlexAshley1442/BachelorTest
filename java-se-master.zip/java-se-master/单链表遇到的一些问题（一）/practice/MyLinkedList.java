package practice;
class Node{
    public int vel;
    public Node next;

    public Node(int vel) {
        this.vel = vel;
    }
}
public class MyLinkedList {
    public Node head;
    //头差法
    public void addFirsh(int data){
        Node node=new Node(data);
        if(this.head!=null){
            node.next=this.head;
            this.head=node;
        }else{
            this.head=node;
        }
    }
    //尾插法
    public void addLast(int data){
        Node node=new Node(data);
        Node cur=this.head;
        if(cur!=null) {
            while (cur.next != null) {
                cur = cur.next;
            }
            cur.next = node;
        }else {
            this.head=node;
        }
    }
    //任意位置插入，第一个数剧节点为0号下标
    public Node sub01(int index){
        Node cur=this.head;
        int count=0;
        while (count!=index-1){
            count++;
            cur=cur.next;
        }
        return cur;
    }
    public void addIndex(int index,int data){
        if(index<0||index>size()) {
            System.out.println("输入的下标有问题");
            return;
        }
        if(index==0){
            addFirsh(data);
            return;
        }
        if(index==size()){
            addLast(data);
            return;
        }
        Node node=new Node(data);
        Node cur=sub01(index);
        node.next=cur.next;
        cur.next=node;
    }
    //查找是否包含关键字vel是否在单链表当中
    public boolean contains(int vel){
        if(this.head==null)return false;
        Node cur=this.head;
        while (cur!=null){
            if(cur.vel==vel){
                return true;
            }
            cur=cur.next;
        }
        return false;
    }
    //删除第一次出现关键字为vel的节点
    public Node sub02(int vel){
        Node cur=this.head;
        while (cur!=null){
            if(cur.next.vel==vel){
                return cur;
            }
            cur=cur.next;
        }
        return null;
    }
    public void remove(int vel){
        if(this.head==null)return;
        Node cur=sub02(vel);
        if(cur==null){
            System.out.println("没有看到");
            return;
        }
        Node cur02=cur.next;
        cur.next=cur02.next;
    }
    //删除所有值为vel的节点
    public void removeAllvel(int vel){
        if (this.head==null)return;
        Node pev=this.head;
        Node cur=this.head.next;
        while (cur!=null){
            if(cur.vel==vel){
                pev.next=cur.next;
                cur=cur.next;
            }else {
                pev=cur;
                cur=cur.next;
            }
        }
    }
    //打印长度
    public int size(){
        Node cur=this.head;
        int count=0;
        while (cur!=null){
            count++;
            cur=cur.next;
        }
        return count;
    }
    //打印链表
    public void dispaly(){
        Node cur=this.head;
        while (cur!=null){
            System.out.print(cur.vel+" ");
            cur=cur.next;
        }
        System.out.println();
    }
    public void dispaly02(Node newHesd){
        Node cur=newHesd;
        while (cur!=null){
            System.out.print(cur.vel+" ");
            cur=cur.next;
        }
        System.out.println();
    }
    //清空
    public void clear(){
        while (this.head!=null){
            Node cur=this.head.next;
            this.head.next=null;
            this.head=cur;
        }
    }
    //反转单链表
    public Node reverseList() {
        if(head==null||head.next==null)return null;
        Node cur=this.head;
        Node newHead=null;
        while (cur!=null){
            Node curNext=cur.next;
            cur.next=newHead;
            newHead=cur;
            cur=curNext;
        }
        return newHead;
    }
    //中间节点
    public Node middleNode() {
        Node fast=this.head;
        Node flow=this.head;
        while (fast!=null&&fast.next!=null){
            fast=fast.next.next;
            flow=flow.next;
        }
        return flow;
    }
    //输入链表倒数节点
    public Node FindKthToTail(int k) {
        if(head==null)return null;
        if(k<=0){
            System.out.println("输入的参数有误");
            return null;
        }
        Node fast=this.head;
        Node slow=this.head;
/*        int count=0;
        while (count<k-1){
            fast=fast.next;
        }*/

        while (k-1!=0) {
            if (fast.next != null) {
                fast = fast.next;
                k--;
            } else {
                return null;
            }
        }
        while (fast.next!=null){
            fast=fast.next;
            slow=slow.next;
        }
        return slow;
    }
    //将两个链表合并
    public Node mergeTwoLists(Node headA, Node headB) {
    if(headA==null)return headB;
    if(headB==null)return headA;
    if(headA==null&&headB==null)return null;
    Node newNode=new Node(-1);
    Node temp=newNode;
    while (headA!=null&&headB!=null){
        if(headA.vel<headB.vel){
            temp.next=headA;
            headA=headA.next;
        }else {
            temp.next=headB;
            headB=headB.next;
        }
        temp=temp.next;
    }
    if(headA==null){
        temp.next=headB;
    }
    if(headB==null){
        temp.next=headA;
    }
    return newNode.next;
    }
}
