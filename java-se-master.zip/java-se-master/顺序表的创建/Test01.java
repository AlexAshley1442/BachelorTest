package Test09;

import java.util.Arrays;

public class Test01 {
    public static void main(String[] args) {
        MyArrayList myArrayList=new MyArrayList();
        myArrayList.add(0,10);
        myArrayList.add(1,50);
        myArrayList.add(2,70);
        myArrayList.display();
        System.out.println(myArrayList.contains(4));
        System.out.println(myArrayList.search(10));
        System.out.println(myArrayList.size());
        myArrayList.remove(10);
        myArrayList.display();
        System.out.println("===================");
        myArrayList.clear();
        myArrayList.display();
    }
}
