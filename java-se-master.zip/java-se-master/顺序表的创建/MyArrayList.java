package Test09;

import java.util.Arrays;

public class MyArrayList {
    public int[] elem;
    public int useSize;
    private static int capacity=10;

    public MyArrayList(){
        this.elem=new int[capacity];
    }

    // 打印顺序表
    public void display() {
        for (int i=0;i<this.useSize;i++){
            System.out.print(this.elem[i]+" ");
        }
        System.out.println();
    }
    // 在 pos 位置新增元素
    public boolean isFull(){
        return this.useSize==capacity;
    }
    public void add(int pos, int data) {
        if(pos>this.useSize||pos<0){
            System.out.println("错误");
            return;
        }
        if(isFull()){
            this.elem= Arrays.copyOf(this.elem,2*capacity);
            capacity*=2;//新的容量
        }

        for(int i=useSize-1;i>=pos;i--){
            this.elem[i+1]=this.elem[i];
        }
        elem[pos]=data;
        this.useSize++;
    }
    public boolean isEmpty(){
        return this.useSize==0;
    }
    // 判定是否包含某个元素
    public boolean contains(int toFind) {
        if(isEmpty())return false;
        for (int i=0;i<this.useSize;i++){
            if(this.elem[i]==toFind){
                return true;
            }
        }
        return false;
    }
    // 查找某个元素对应的位置
    public int search(int toFind) {
        if(isEmpty())return -1;
        for (int i = 0; i < this.useSize; i++) {
            if (this.elem[i] == toFind) {
                return i;
            }
        }
        return -1;
    }
    // 获取 pos 位置的元素
    public int getPos(int pos) {
        if(isEmpty())return -1;
        if(pos>=0&&pos<this.useSize){
            return this.elem[pos];
        }
        System.out.println("pos不合法");
        return -1;
    }
    // 给 pos 位置的元素设为 value
    public void setPos(int pos, int value) {
        if(pos<0||pos>=this.useSize){
            System.out.println("pos不合法");
            return;
        }
        if(isEmpty()){
            System.out.println("顺序表为空");
            return;
        }
        this.elem[pos]=value;
    }
    //删除第一次出现的关键字key
    public void remove(int toRemove) {
        if(isEmpty()){
            System.out.println("顺序表为空");
            return;
        }
/*        int index = -1;
        for(int i=0;i<this.useSize;i++){
            if(this.elem[i]==toRemove){
                index=i;
            }
        }*/
        int index=search(toRemove);
        if(index==-1){
            System.out.println("没有这个值");
            return;
        }

        for(int i=index;i<this.useSize-1;i++){
            this.elem[i]=this.elem[i+1];
        }
        this.elem[this.useSize]=0;
        this.useSize--;
    }
    // 获取顺序表长度
    public int size() {
        return this.useSize;
    }
    // 清空顺序表
    public void clear() {
        for(int i=0;i<this.useSize;i++){
            this.elem[i]=0;
        }
        this.useSize=0;
    }

}
