package opeartion;

import book.BookList;

public class ReturnOperation implements IOPeration{
    @Override
    public void work(BookList bookList) {

    }
}
