package opeartion;

import book.Book;
import book.BookList;

import java.util.Scanner;

public class FindOperation implements IOPeration{
    @Override
    public void work(BookList bookList) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入图书的名字：");
        String name=scanner.nextLine();
        int size=bookList.getSize();
        for (int i = 0; i < size; i++) {
            Book book1=bookList.getBook(i);
            if(book1.getName().equals(name)){
                System.out.println("找到这本书！");
                System.out.println(book1);
                return;
            }
        }
        System.out.println("查找失败！");
    }
}
