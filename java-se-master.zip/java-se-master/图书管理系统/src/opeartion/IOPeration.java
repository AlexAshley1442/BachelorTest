package opeartion;

import book.BookList;

public interface IOPeration {
    void work(BookList bookList);
}
