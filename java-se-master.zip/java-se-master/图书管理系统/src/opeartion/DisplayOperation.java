package opeartion;

import book.Book;
import book.BookList;

public class DisplayOperation implements IOPeration{
    @Override
    public void work(BookList bookList) {
        System.out.println("打印所有图书！");
        int size= bookList.getSize();
        for (int i = 0; i < size; i++) {
            Book book=bookList.getBook(i);
            System.out.println(book);
        }
    }
}
