package Dask04;

public class Dask03 {
    public static void main(String[] args) {
        int n=2;
        int add=0;
        for(int i=1;i<=n;i++){
            int num=1;
            for(int j=1;j<=i;j++){
                num=num*j;
            }
            add+=num;
        }
        System.out.println(add);
    }
}
