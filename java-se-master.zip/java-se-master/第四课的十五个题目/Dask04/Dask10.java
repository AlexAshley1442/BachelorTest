package Dask04;

public class Dask10 {
    public static void hanno(int n,String begin,String mid,String end){
        if(n==1){
            System.out.println(begin+"--->"+end);
        }else{
            hanno(n-1,begin,end,mid);
            System.out.println(begin+"--->"+end);
            hanno(n-1,mid,begin,end);
        }
    }
    public static void main(String[] args) {
        hanno(5,"x","y","z");
    }
}
