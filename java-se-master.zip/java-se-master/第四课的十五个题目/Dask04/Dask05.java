package Dask04;

public class Dask05 {
    public static void main(String[] args) {
        int[] arr={8,7,6,5,4,3,2,1};
        int[] arr1=new int[8];
        int a=0,b=0;
        for(int i=0;i<arr.length;i++){
            if(arr[i]%2!=0){
                arr1[a]=arr[i];
                a++;
            }
            if(arr[i]%2==0){
                arr1[arr1.length-b-1]=arr[i];
                b++;
            }
        }
        for(int i=0;i<arr1.length;i++) {
            System.out.print(arr1[i]);
        }
    }
}
