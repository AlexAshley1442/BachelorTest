package Dask04;

public class Dask12 {
    private static int num=0;
    public static int add(int n){
        if(n>9){
            add(n/10);
        }
        num+=n%10;
        return num;
    }
    public static void main(String[] args) {
        System.out.println(add(12));
    }
}
