package Dask04;

public class Dask06 {
    public static int max01(int i,int j){
        if(i<j){
            int temp;
            temp=i;
            i=j;
            j=temp;
        }
        return i;
    }
    public static int max02(int a,int b,int c){
        int m=max01(a,b);
        int n=max01(a,c);

        return max01(m,n);
    }
    public static void main(String[] args) {
        System.out.println(max02(10,20,30));
    }
}
