package Dask04;

import java.util.Scanner;

public class Dask04 {
    public static int ride(int n){
        if(n==1){return 1;}

        return n*ride(n-1);
    }
    public static void main(String[] args) {
        Scanner sca=new Scanner(System.in);
        int a=sca.nextInt();
        System.out.println(ride(a));
    }
}
