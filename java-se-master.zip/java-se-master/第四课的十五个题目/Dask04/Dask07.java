package Dask04;

public class Dask07 {
    public static int add(int m,int n){
        if(m<n){
            int temp;
            temp=m;
            m=n;
            n=temp;
        }
        return m;
    }
    public static double add(double m,double n){
        if(m<n){
            double temp;
            temp=m;
            m=n;
            n=temp;
        }
        return m;
    }
    public static double add(double m,double n,int a){
        double temp;
        if(m<n){temp=m;m=n;n=temp;}
        if(m<a){temp=m;m=a;a=(int)temp;}
        return m;
    }
    public static void main(String[] args) {
        System.out.println(add(10,30));
        System.out.println(add(0.59,0.42));
        System.out.println(add(5.5,6.6,10));
    }
}
