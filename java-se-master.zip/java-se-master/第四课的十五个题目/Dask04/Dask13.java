package Dask04;

public class Dask13 {
    public static void add(int n){
        if(n>9){
            add(n/10);
        }
        System.out.print(n%10+" ");
    }
    public static void main(String[] args) {
        add(123231);
    }
}
