package Dask04;

import java.util.Scanner;

public class Dask09 {
    public static int frog(int n){
        if(n==1){return 1;}
        else if(n==2){return 2;}

        return frog(n-1)+frog(n-2);
    }
    public static void main(String[] args) {
        Scanner sca=new Scanner(System.in);
        int a=sca.nextInt();
        System.out.println(frog(a));
    }
}
