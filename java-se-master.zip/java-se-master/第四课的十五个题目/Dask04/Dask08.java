package Dask04;

public class Dask08 {
    public static int add(int a,int b){
        return a+b;
    }
    public static double add(double a,double b,double c){
        return a+b+c;
    }
    public static void main(String[] args) {
        System.out.println(add(10,20));
        System.out.println(add(1.2,2.3,5.4));
    }
}
