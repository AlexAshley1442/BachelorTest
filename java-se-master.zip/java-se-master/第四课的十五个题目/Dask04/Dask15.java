package Dask04;

public class Dask15 {
    public static int ride(int n){
        if(n==1){
            return 1;
        }

        return n*ride(n-1);
    }
    public static void main(String[] args) {
        System.out.println(ride(4));
    }
}
