package Dask05;

import java.util.Arrays;

public class Dask03 {
    public static int[] transform(int[] arrays1){
        int[] arrays2=new int[arrays1.length];
        for (int i = 0; i < arrays1.length; i++) {
            arrays2[i]=arrays1[i]*2;
        }
        return arrays2;
    }
    public static void main(String[] args) {
        int[] arrays={1,2,3};
        int[] arrays2=transform(arrays);
        System.out.println(Arrays.toString(arrays2));
    }
}
