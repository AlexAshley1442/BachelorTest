package Dask05;

import java.util.Arrays;

public class Dask05 {
    public static void main(String[] args) {
        int[] arrays=new int[100];
        for (int i=1;i<=arrays.length;i++){
            arrays[i-1]=i;
        }
        System.out.print(Arrays.toString(arrays)+" ");
    }
}
