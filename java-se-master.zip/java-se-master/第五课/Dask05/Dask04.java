package Dask05;

public class Dask04 {
    public static void printArray(int[] arrays1){
        for (int i = 0; i < arrays1.length; i++) {
            System.out.print(arrays1[i]+" ");
        }
    }
    public static void main(String[] args) {
        int[] arrays={1,2,3,4,5,6};
        printArray(arrays);
    }
}
