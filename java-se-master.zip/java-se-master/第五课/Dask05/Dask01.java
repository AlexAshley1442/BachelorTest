package Dask05;

public class Dask01 {
    public static double avg(int[] arrays1){
        double num=0;
        for(int i=0;i< arrays1.length;i++){
            num+=arrays1[i];
        }
        return num/arrays1.length;
    }

    public static void main(String[] args) {
        int[] arrays={1,2,3,4,5,6};
        double a=avg(arrays);
        System.out.println(a);
    }
}
