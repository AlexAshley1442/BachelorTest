package Test13;

public class practice04 {
    public Node swapPairs(Node head) {
        Node newHead=new Node(-1);
        Node temp=newHead;
        Node cur=head;
        if(cur==null||cur.next==null){
            return head;
        }
        while (cur!=null&&cur.next!=null){
            Node curNext=cur.next;
            cur.next=cur.next.next;
            curNext.next=cur;
            temp.next=curNext;
            temp=cur;
            cur=cur.next;
        }
        return newHead.next;
    }
}

/*
* 给定一个链表，两两交换其中相邻的节点，并返回交换后的链表。

你不能只是单纯的改变节点内部的值，而是需要实际的进行节点交换。
* */