package Test13;

public class practice02 {
    public Node removeNthFromEnd(Node head, int n) {
        Node newHead=new Node(-1);
        newHead.next=head;
        if(head==null){return null;}
        if(n<=0){
            System.out.println("输入有误");
            return null;
        }
        Node fast=newHead;
        Node slow=newHead;

        while (n!=0){
            if(fast.next!=null) {
                fast = fast.next;
                n--;
            }else {
                return null;
            }
        }

        while (fast.next!=null){
            fast=fast.next;
            slow=slow.next;
        }

        slow.next=slow.next.next;
        return newHead.next;
    }
}
