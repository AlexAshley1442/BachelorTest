package Test13;

public class practice03 {
    public Node mergeTwoLists(Node l1, Node l2) {
        if(l1==null) return l2;
        if(l2==null) return l1;
        if(l1==null&&l2==null) return null;
        Node newHead=new Node(-1);
        Node temp=newHead;

        while (l1!=null&&l2!=null){
            if(l1.data<l2.data){
                temp.next=l1;
                l1=l1.next;
            }else{
                temp.next=l2;
                l2=l2.next;
            }
            temp=temp.next;
        }

        if(l1==null){
            temp.next=l2;
        }
        if(l2==null){
            temp.next=l1;
        }

        return newHead.next;
    }
}
