import openpyxl


def delete_columns(filename, sheetname, column_list):
    # 打开Excel文件
    wb = openpyxl.load_workbook(filename)

    # 选择指定的工作表
    sheet = wb[sheetname]

    # 循环遍历序号列表
    for column_index in column_list:
        # 根据序号获取对应的列字母
        column_letter = openpyxl.utils.get_column_letter(column_index)

        # 删除指定的列
        sheet.delete_cols(column_index)

        # 更新后续列的序号
        for row in sheet.iter_rows(min_row=1, min_col=column_index + 1):
            for cell in row:
                new_column_letter = openpyxl.utils.get_column_letter(cell.column - 1)
                cell.coordinate = new_column_letter + str(cell.row)

    # 保存修改后的Excel文件
    wb.save(filename)


# 示例用法
filename = '..\data/add_data - 副本.xlsx'  # Excel文件名
sheetname = 'Sheet1'  # 工作表名
column_list = [2, 4, 6]  # 要删除的列序号列表

delete_columns(filename, sheetname, column_list)
