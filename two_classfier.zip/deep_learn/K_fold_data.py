import torch


def get_k_fold_data(k, i, train_feature, train_label):
    # 返回第i折交叉验证时所需要的训练和验证数据
    assert k > 1
    fold_size = train_feature.shape[0] // k
    X_train, y_train = None, None
    for j in range(k):
        idx = slice(j * fold_size, (j + 1) * fold_size)
        X_part, y_part = train_feature[idx, :], train_label[idx]
        if j == i:
            X_valid, y_valid = X_part, y_part
        elif X_train is None:
            X_train, y_train = X_part, y_part
        else:
            X_train = torch.cat((X_train, X_part), dim=0)
            y_train = torch.cat((y_train, y_part), dim=0)
    return X_train, y_train, X_valid, y_valid
