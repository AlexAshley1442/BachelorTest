import torch
import torch.nn as nn

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.model=nn.Sequential(
            nn.Linear(in_features=25, out_features=50),
            nn.ReLU(),
            nn.Linear(in_features=50, out_features=2)
        )

    def forward(self, x):
        return self.model(x)

# 测试
# if __name__ == '__main__':
#     mynet = Net()
#     input = torch.ones(25)
#     output = mynet(input)
#     print(output)