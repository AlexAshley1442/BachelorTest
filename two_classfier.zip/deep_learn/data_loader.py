import pandas as pd
import torch
from torch.utils import data

def dataloader(data_path):
    data = pd.read_excel(data_path)
    all_feather = pd.concat([data.iloc[:, 2:]])
    all_label = pd.concat([data.iloc[:, 1]])
    all_feather = torch.tensor(all_feather.values, dtype=torch.float32)
    all_label = torch.tensor(all_label.values, dtype=torch.float32)
    print(all_feather)
    return all_feather, all_label