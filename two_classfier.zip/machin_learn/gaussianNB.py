import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

data = pd.read_excel('..\data\add_data - 副本.xlsx')
all_feather = pd.concat([data.iloc[:, 2:]])
all_label = pd.concat([data.iloc[:, 1]])

x_train, x_test, y_train, y_test = train_test_split(all_feather, all_label, train_size=0.8, random_state=None, shuffle=True)
# 创建逻辑回归分类器
model = GaussianNB()
# 使用训练数据拟合分类器
model.fit(x_train, y_train)

# 使用测试数据预测标签
y_pred = model.predict(x_test)
print(y_pred.reshape(-1))
print(y_test.to_numpy().reshape(-1))
# 计算预测准确率
accuracy = accuracy_score(y_test, y_pred)

print('预测准确率:', accuracy)