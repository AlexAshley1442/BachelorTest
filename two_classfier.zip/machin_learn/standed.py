import pandas as pd
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import openpyxl

# 读入你给我1b表
data = pd.read_excel('..\data/add_data - 副本.xlsx')

scaler = StandardScaler()

x = pd.concat([data.iloc[:, 2:]])
print(x)
x = scaler.fit_transform(x)
x = pd.DataFrame(x)
y = pd.concat([data.iloc[:, 1]])
print(y)
# 定义交叉验证折数
k = 6

# 创建随机森林分类器
num = 20

rf = RandomForestClassifier(n_estimators=100, random_state=8)

        # 创建K折交叉验证对象
kf = KFold(n_splits=k, shuffle=True, random_state=0)

        # 定义评估指标列表
accuracy_list = []
special_patient = []
        # 循环进行交叉验证
for train_index, val_index in kf.split(x):
     # print(train_index )
     print(val_index)
     x_train, x_val = x.iloc[train_index], x.iloc[val_index]
     y_train, y_val = y.iloc[train_index], y.iloc[val_index]
       # 使用训练集拟合模型
     rf.fit(x_train ,y_train)

            # 在验证集上进行预测
     y_pred = rf.predict(x_val)
     # print(y_pred)
            # 计算准确率
     accuracy = accuracy_score(y_val, y_pred)
            # print(accuracy)
     accuracy_list.append(accuracy)

     y_val = y_val.values  # 将y_val转换为NumPy数组

     for i in range(len(val_index)):
          if y_val[i] != y_pred[i]:
               special_patient.append(val_index[i])

        # 计算平均准确率
average_accuracy = sum(accuracy_list) / k

        # 输出最终评估结果
print("平均准确率:", average_accuracy)
print(len(special_patient))




